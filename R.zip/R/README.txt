put all dll files in R\bin\(x64 or i386)
rename Rblas.dll to Rblas.default.dll
rename Rlapack.dll to Rlapack.default.dll
copy libopenblas.dll and rename it to Rblas.dll
copy libopenblas.dll and rename it to Rlapack.dll

